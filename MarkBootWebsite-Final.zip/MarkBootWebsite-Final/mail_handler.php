<?php
	if(isset($_POST['submit'])){
		$name=$_POST['name'];
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		$msg=$_POST['msg'];

		$to='support@markboot.com'; // Receiver Email ID, Replace with your email ID
		$subject='Contact';
		$message="Name :".$name."\n"."Phone :".$phone."\n"."Email:".$email."\n"."Wrote the following :".$msg;
		$headers="From: ".$email;

		if(mail($to, $subject, $message, $headers)){
			echo '<script> alert("Sent Successfully! Thank you") </script>';
		}
		else{
			echo '<script> alert("Something went wrong!") </script>';
		}
	}
?>